<?php return array (
  'leads-table' => 'App\\Http\\Livewire\\LeadsTable',
);