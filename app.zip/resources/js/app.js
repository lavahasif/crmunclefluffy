import './bootstrap';
window.onload = function () {
    // alert("W"+window.screen.width+"H"+window.screen.height)
}