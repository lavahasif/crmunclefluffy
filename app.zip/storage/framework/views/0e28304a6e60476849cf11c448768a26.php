

<?php $__env->startSection('title', 'NewLead'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-Success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <form method="GET" action="<?php echo e(route('leadadd')); ?>">
        <div class="card2">
            <h5 class="head">New Lead</h5>

            <select class="myinput" name="opt_status" aria-placeholder="Status">
                <option value="0" disabled selected>Status</option>
                <option value="0">New</option>
                <option value="1">Contacted</option>
                <option value="2">Not Interested</option>
            </select>
            <input type="text" id="txt_name" name="txt_name" class="myinput" placeholder="Name"
                value="<?php echo e(old('txt_name')); ?>">
            <?php echo e($errors->first('txt_name')); ?>

            <input type="text" id="txt_email" name="txt_email" class="myinput"
                placeholder="Eamil"value="<?php echo e(old('txt_email')); ?>">
            <?php echo e($errors->first('txt_email')); ?>

            <input type="text" id="txt_phone" name="txt_phone" class="myinput" placeholder="Phone"
                value="<?php echo e(old('txt_phone')); ?>">
            <?php echo e($errors->first('txt_phone')); ?>

            <input type="text" id="txt_country" name="txt_country" class="myinput" placeholder="Country"
                value="<?php echo e(old('txt_country')); ?>">
            <?php echo e($errors->first('txt_country')); ?>

            <input type="text" id="txt_interest" name="txt_interest" class="myinput" placeholder="Interest"
                value="<?php echo e(old('txt_interest')); ?>">

            <?php echo e($errors->first('txt_interest')); ?>


            <select class="myinput" name="opt_source" aria-placeholder="Status">
                <option value="0" disabled selected>Source</option>
                <option value="0">Instagram</option>
                <option value="1">FaceBook</option>
                <option value="2">TikTok</option>
            </select>
            <input type="text" id="txt_remark" class="myinput" name="txt_remark" placeholder="Remark"
                value="<?php echo e(old('txt_remark')); ?>">
            <?php echo e($errors->first('txt_remark')); ?>

            <button onclick="" id="btn_login">
                Save
            </button>

        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\crmunclefluffy\resources\views/Admin/NewLead.blade.php ENDPATH**/ ?>