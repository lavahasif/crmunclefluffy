<style scoped>
    li.page-item {
        margin-right: .5rem;
        border-radius: unset !important;
    }

    a.page-link {
        background-color: #efefef;
        border-radius: 0px;
        border-radius: 0px !important;
        color: darkgray;
    }

    .page-item:first-child .page-link {
        border-top-left-radius: unset;
        border-bottom-left-radius: unset;
    }

    .page-item:last-child .page-link {

        border-top-right-radius: unset;
        border-bottom-right-radius: unset;

    }

    .page-link.active,
    .active>.page-link {

        background-color: #777479 !important
    }
</style>
<?php if($paginator->hasPages()): ?>
    <nav>
        <ul class="pagination">
            
            

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li class="disabled" aria-disabled="true"><span><?php echo e($element); ?></span></li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li class="active  page-item" aria-current="page"><span
                                    class="page-link"><?php echo e($page); ?></span></li>
                        <?php else: ?>
                            <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            
        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH E:\xampp\htdocs\crmunclefluffy\resources\views/vendor/pagination/default.blade.php ENDPATH**/ ?>