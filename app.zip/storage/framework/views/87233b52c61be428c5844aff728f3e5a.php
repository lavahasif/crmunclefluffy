

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <form method="get" action="<?php echo e(route('login')); ?>">
        <div class="card">

            <h5 class="head">User Login</h5>
            <input type="text" id="txt_username" name="txt_username" placeholder="UserName" value="<?php echo e(old('txt_username')); ?>">
            <?php echo e($errors->first('txt_username')); ?>

            <input type="text" id="txt_password" name="txt_password" placeholder="Password"
                value="<?php echo e(old('txt_password')); ?>">
            <?php echo e($errors->first('txt_password')); ?>

            <button onclick="" id="btn_login">
                Login
            </button>

        </div>
    </form>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\crmunclefluffy\resources\views/Login/Login.blade.php ENDPATH**/ ?>