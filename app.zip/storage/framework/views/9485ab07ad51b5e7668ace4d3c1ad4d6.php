<html>

<head>
    <title>AMP - <?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(asset('build/app.css')); ?>">
    <link rel="icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/x-icon">
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
    <?php $__env->startSection('sidebar'); ?>
        <style scoped>
            @media (min-width: 992px) {
                .navbar-expand-lg .navbar-toggler {
                    display: block;
                }

                .navbar-expand-lg .navbar-collapse {
                    /* display: flex!important; */
                    flex-basis: auto;
                }

                .navbar-expand-lg {
                    flex-wrap: nowrap;
                    justify-content: space-between;
                    display: flex !important;
                }


                .navbar-expand-lg .navbar-collapse {
                    display: none !important;
                    flex-basis: auto;
                }

                .collapse:not(.show) {
                    display: none;
                }
            }
        </style>
        <nav class="navbar navbar-expand-lg navbar-light bg-prcolor nav-text ">
            <a class="navbar-brand " href="#">
                <img src="<?php echo e(asset('images/favicon.png')); ?>" class="left_nav_logo">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                
                <img src="<?php echo e(asset('images/menu.png')); ?>" class="right_nav_logo">
            </button>
            
        </nav>
    <?php echo $__env->yieldSection(); ?>

    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <script src="<?php echo e(asset('build/app2.js')); ?>"></script>
    <style scoped>
        @media (min-width: 992px) {
            .navbar-expand-lg .navbar-toggler {
                display: block;
            }

            .navbar-expand-lg .navbar-collapse {
                /* display: flex!important; */
                flex-basis: auto;
            }

            .navbar-expand-lg {
                flex-wrap: nowrap;
                justify-content: space-between;
                display: flex !important;
            }


            .navbar-expand-lg .navbar-collapse {
                display: none !important;
                flex-basis: auto;
            }

            .collapse:not(.show) {
                display: none;
            }
        }
    </style>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH E:\xampp\htdocs\crmunclefluffy\resources\views/Layouts/MainLayout.blade.php ENDPATH**/ ?>