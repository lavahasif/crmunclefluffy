<table>
    <thead>
        <tr>
            <th style="padding-left: 2rem">Status</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Country</th>
            <th>Interest</th>
            <th>Source</th>
            <th>Date</th>
            <th>Remark</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <div class="status">
                        <div class="statuscolor" style="background-color:<?php echo e($single->Status->color ?? 'white'); ?> ">
                        </div>
                        <div class="st2">
                            <p class="status_p"><?php echo e($single->Status->name?? "New"); ?></p>
                        </div>
                    </div>
                </td>
                <td><?php echo e($single->customer->name); ?></td>
                <td><?php echo e($single->customer->Email); ?></td>
                <td><?php echo e($single->customer->phone); ?></td>
                <td><?php echo e($single->customer->country); ?></td>
                <td><?php echo e($single->interest); ?></td>
                <td><?php echo e($single->Source->name??"TikTok"); ?></td>
                <td><?php echo e(date('d F Y', strtotime($single->created_at))); ?></td>
                <td><?php echo e($single->remark); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </tbody>


</table>
<?php /**PATH E:\xampp\htdocs\crmunclefluffy\resources\views/livewire/leads-table.blade.php ENDPATH**/ ?>